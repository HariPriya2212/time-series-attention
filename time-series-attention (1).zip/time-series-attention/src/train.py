# training loop
