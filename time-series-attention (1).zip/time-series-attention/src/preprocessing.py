# windowing and scaling
